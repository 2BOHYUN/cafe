package member;

public interface MemberService {
	boolean id_check(String userid);
	boolean insert(MemberVO vo);
	boolean update(MemberVO vo);
	boolean delete(String userid);
}
