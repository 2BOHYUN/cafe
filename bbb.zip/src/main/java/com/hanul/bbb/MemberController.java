package com.hanul.bbb;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

@Controller @SessionAttributes("category")
public class MemberController {
	
	
	//�α��� ȭ�� ��û
	@RequestMapping("/login")
	public String login(Model model) {
		model.addAttribute("category","");
		return "member/login";
	}

	
	//ȸ������ ȭ�� ��û
	@RequestMapping("/member")
	public String member(Model model) {
		model.addAttribute("category","");
		return	"member/join";
	}
}
